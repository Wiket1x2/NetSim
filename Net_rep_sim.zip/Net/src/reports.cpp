//
// Created by krzys on 10.12.2019.
//

#include "reports.hpp"

void generate_structure_report(Factory& f,std::ostream& os) {}
void generate_simulation_turn_report(Factory& f,std::ostream& os, Time t) {}