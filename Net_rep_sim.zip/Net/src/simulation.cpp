//
// Created by krzys on 10.12.2019.
//
#include "simulation.hpp"

void simulate(Factory& f,TimeOffset d, std::function<void(Factory&,Time)> rf) {}

