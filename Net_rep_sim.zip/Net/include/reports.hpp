//
// Created by krzys on 10.12.2019.
//

#ifndef NET_SIM_REPORTS_HPP
#define NET_SIM_REPORTS_HPP

#include "factory.hpp"

void generate_structure_report(Factory& f,std::ostream& os);
void generate_simulation_turn_report(Factory& f,std::ostream& os, Time t);

class IntervalReportNotifier {
public:
    IntervalReportNotifier(TimeOffset to): to_(to) {}
    bool should_generate_report(Time t) { return t==1 || t-1%to_; }

private:
    TimeOffset to_;
};

class SpecificTurnsReportNotifier {
public:
    SpecificTurnsReportNotifier(std::set<Time> turns): turns_(turns) {}
    bool should_generate_report(Time t) { return std::find(turns_.cbegin(),turns_.cend(),t)!=turns_.cend();}
private:
    std::set<Time> turns_;
};

#endif //NET_SIM_REPORTS_HPP
