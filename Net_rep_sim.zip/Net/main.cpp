#include <iostream>
#include "package.hpp"
#include "storage_types.hpp"
#include "nodes.hpp"
#include "factory.hpp"


int main() {


    std::cout << "Hello, World!" << std::endl;
    return 0;
}
