//
// Created by krzys on 10.12.2019.
//

#include "package.hpp"

std::set<ElementID> Package::assigned_IDs;
std::set<ElementID> Package::freed_IDs;

Package::Package() {
    if (!freed_IDs.empty()) {
        id_= *freed_IDs.begin(); //czy cbegin()?
        freed_IDs.erase(id_);
        assigned_IDs.insert(id_);
    }
    else if (!assigned_IDs.empty()) {
        id_= *assigned_IDs.rbegin()+1;
        assigned_IDs.insert(id_);
    }
    else {
        id_=0;
        assigned_IDs.insert(id_);
    }
}

Package::~Package() {
    assigned_IDs.erase(id_);
    freed_IDs.insert(id_);
}