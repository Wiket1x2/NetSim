//
// Created by krzys on 10.12.2019.
//

#include "storage_types.hpp"


void PackageQueue::push(Package&& package) {
    switch(storage_type_) {
        case PackageQueueType::FIFO:
            pdeq_.emplace_back(std::move(package));
            break;
        case PackageQueueType::LIFO:
            pdeq_.emplace_front(std::move(package));
            break;

    }

}

Package PackageQueue::pop()  {

    switch(storage_type_) {
        case PackageQueueType::FIFO: {
            Package pack1 = *pdeq_.begin();
            pdeq_.pop_front();
            return pack1;
        }
        case PackageQueueType::LIFO: {
            Package pack2 = *pdeq_.rend();
            pdeq_.pop_back();
            return pack2;
        }
    }

}
