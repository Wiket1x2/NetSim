#include <iostream>
#include <deque>
#include <list>
int main() {
    std::cout << "Hello, World!" << std::endl;
    std::deque<int> mydeq{1,2,3,4,5,6};

    return 0;
}
