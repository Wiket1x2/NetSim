//
// Created by krzys on 10.12.2019.
//

#include "package.hpp"

std::set<ElementID> Package::assigned_IDs;
std::set<ElementID> Package::freed_IDs;

Package::Package() {
    if (!freed_IDs.empty()) {
        id_= *freed_IDs.begin(); //przeciazone nie trzeba cbegin()
        freed_IDs.erase(id_);
        assigned_IDs.insert(id_);
    }
    else if (!assigned_IDs.empty()) {
        id_= *(assigned_IDs.rbegin())+1;
        assigned_IDs.insert(id_);
    }
    else {
        id_=0;
        assigned_IDs.insert(id_);
    }
}

Package& Package::operator=(Package&& other) {
    id_=std::move(other.id_);
    other.id_=INT_MAX;
    return (*this);
}

Package::~Package() {
    if (id_!=INT_MAX) { //bo produkt ktory jest przypisywany - std::move(product) bedzie mial id_ ale nie wlasciwe....
        assigned_IDs.erase(id_);
        freed_IDs.insert(id_);
    }
}