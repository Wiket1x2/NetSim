//
// Created by krzys on 10.12.2019.
//

#ifndef NET_SIM_PACKAGE_HPP
#define NET_SIM_PACKAGE_HPP

#include "types.hpp"
#include <set>



class Package {

public:
    Package(); //czy mamy zamiescic drugi konstruktor Package(ElementID id): id_(id){} ktory bedzie tworzyl obiekt na podst przekazanego id - patrz wczytywanie z pliku?
    // dodac obsluge gdy id jest zajete - tak na jedno i drugie pytanie
    Package(const Package&)= delete;
    Package(Package&& other): id_(std::move(other.id_)) {}; //czy Package&& ma byc const?
    Package& operator=(Package&& other); //gdzie const , czy const ma byc typ zwracany?
    ElementID get_id() const { return id_;}
    ~Package();


private:
    ElementID id_;
    static std::set<ElementID> assigned_IDs;
    static std::set<ElementID> freed_IDs;

};

#endif //NET_SIM_PACKAGE_HPP
