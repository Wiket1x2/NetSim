// 5: Kasztelewicz (302858), Szczerba (302924), Gorecki (302847)

#include <factory.hpp>

void Factory::do_package_passing() {
    for(auto& idx : r_list) idx.send_package();
    for(auto& idx : w_list) idx.send_package();
}

// 5: Kasztelewicz (302858), Szczerba (302924), Gorecki (302847)