#include <iostream>
#include <deque>
#include <list>
int main() {

    return 0;
}
