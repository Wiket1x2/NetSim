//
// Created by krzys on 10.12.2019.
//

#ifndef NET_SIM_HELPERS_HPP
#define NET_SIM_HELPERS_HPP


#include <random>
#include <cstdlib>


double probability_generator_1(); //na uplu nie pisze aby dodac helpers.cpp i nie wiem gdzie definiować funkcje
double probability_generator_2(); //choć zgaduje że jest to mało istotne, bo do testów kłeczka pojdą jedgo nie losowe funkcje.

#endif //NET_SIM_HELPERS_HPP
